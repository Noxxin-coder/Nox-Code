import { afterEach, describe, expect, it, vi } from 'vitest';
import { ProviderRequestError, requestChatCompletion } from '../src/providers/openaiCompatible.js';

describe('OpenAI-like provider handling', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('returns text from a successful completion response', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        choices: [{
          message: { content: 'done' },
        }],
      }),
    }));

    const content = await requestChatCompletion({
      provider: 'ollama',
      baseUrl: 'http://localhost:11434',
      model: 'llama3.1',
    }, [{ role: 'user', content: 'hello' }]);

    expect(content).toBe('done');
  });

  it('throws a provider error when the completion request fails', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
      ok: false,
      status: 500,
      text: async () => 'server exploded',
    }));

    await expect(requestChatCompletion({
      provider: 'ollama',
      baseUrl: 'http://localhost:11434',
      model: 'llama3.1',
    }, [{ role: 'user', content: 'hello' }])).rejects.toBeInstanceOf(ProviderRequestError);
  });
});
