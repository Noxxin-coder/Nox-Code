# Security Policy

## Supported versions

This project is in active development. Security updates are handled on the current main branch.

## Reporting a vulnerability

Please report security issues privately. Do not open a public issue for a suspected vulnerability until a remediation path is agreed.

## Security protections included

- Secret redaction for common token and API key patterns.
- Workspace path validation to prevent directory traversal.
- Dangerous shell command detection.
- Patch validation to block unsafe file paths.
- Default folder exclusions for generated and dependency directories.
