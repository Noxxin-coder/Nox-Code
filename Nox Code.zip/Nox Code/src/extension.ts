import * as vscode from 'vscode';
import { validateModelConfig } from './config.js';
import { scanWorkspace } from './workspace/context.js';

export function activate(context: vscode.ExtensionContext): void {
  const explain = vscode.commands.registerCommand('noxCode.explain', async () => {
    const config = validateModelConfig({
      provider: 'ollama',
      baseUrl: 'http://localhost:11434',
      model: 'llama3.1',
    });

    const workspaceFolders = vscode.workspace.workspaceFolders ?? [];
    const root = workspaceFolders[0]?.uri.fsPath ?? process.cwd();
    const files = await scanWorkspace(root, { maxFiles: 20 });

    const summary = files.slice(0, 5).map((file) => file.path).join(', ') || 'No files indexed';
    void vscode.window.showInformationMessage(`Nox Code ready: ${config.provider} @ ${config.baseUrl} (${summary})`);
  });

  const validate = vscode.commands.registerCommand('noxCode.validateWorkspace', async () => {
    const workspaceFolders = vscode.workspace.workspaceFolders ?? [];
    if (workspaceFolders.length === 0) {
      void vscode.window.showWarningMessage('No workspace folder is open.');
      return;
    }

    const root = workspaceFolders[0].uri.fsPath;
    const files = await scanWorkspace(root, { maxFiles: 50 });
    void vscode.window.showInformationMessage(`Scanned ${files.length} workspace files.`);
  });

  context.subscriptions.push(explain, validate);
}

export function deactivate(): void {
  // Intentionally empty.
}
