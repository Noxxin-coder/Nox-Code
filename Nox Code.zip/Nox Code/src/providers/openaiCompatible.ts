import { normalizeBaseUrl, type ModelConfig, validateModelConfig } from '../config.js';

export class ProviderRequestError extends Error {
  constructor(message: string, public readonly status?: number) {
    super(message);
    this.name = 'ProviderRequestError';
  }
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface CompletionOptions {
  temperature?: number;
  maxTokens?: number;
}

export async function requestChatCompletion(
  config: Partial<ModelConfig>,
  messages: ChatMessage[],
  options: CompletionOptions = {}
): Promise<string> {
  const validated = validateModelConfig(config);
  const url = new URL('/v1/chat/completions', normalizeBaseUrl(validated.baseUrl));
  const payload = {
    model: validated.model,
    messages,
    temperature: options.temperature ?? 0.2,
    max_tokens: options.maxTokens ?? 512,
  };

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(validated.customHeaders ?? {}),
  };

  if (validated.apiKey) {
    headers.Authorization = `Bearer ${validated.apiKey}`;
  }

  const response = await fetch(url.toString(), {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const body = await response.text();
    throw new ProviderRequestError(`Model request failed (${response.status}): ${body.slice(0, 200)}`, response.status);
  }

  const data = (await response.json()) as Record<string, unknown>;
  const choices = Array.isArray(data.choices) ? data.choices : [];
  const firstChoice = choices[0] as Record<string, unknown> | undefined;
  const firstMessage = firstChoice?.message as Record<string, unknown> | undefined;
  const content = firstMessage?.content;

  if (typeof content !== 'string') {
    throw new ProviderRequestError('Model response did not include text output.');
  }

  return content;
}
