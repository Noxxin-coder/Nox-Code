export type ProviderType = 'ollama' | 'lmstudio' | 'llamacpp' | 'omniroute' | 'openai' | 'custom';

export interface ModelConfig {
  provider: ProviderType;
  baseUrl: string;
  model: string;
  apiKey?: string;
  timeoutMs?: number;
  customHeaders?: Record<string, string>;
}

export const DEFAULT_MODEL_CONFIG: ModelConfig = {
  provider: 'ollama',
  baseUrl: 'http://localhost:11434',
  model: 'llama3.1',
  timeoutMs: 60000,
};

export function validateModelConfig(input: Partial<ModelConfig>): ModelConfig {
  const candidate: ModelConfig = {
    ...DEFAULT_MODEL_CONFIG,
    ...input,
  };

  if (!candidate.model || !candidate.model.trim()) {
    throw new Error('A model name is required.');
  }

  if (!candidate.baseUrl || !candidate.baseUrl.trim()) {
    throw new Error('A provider base URL is required.');
  }

  let parsed: URL;
  try {
    parsed = new URL(candidate.baseUrl);
  } catch {
    throw new Error(`Invalid base URL: ${candidate.baseUrl}`);
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error('Provider base URL must use http or https.');
  }

  const allowed = ['ollama', 'lmstudio', 'llamacpp', 'omniroute', 'openai', 'custom'];
  if (!allowed.includes(candidate.provider)) {
    throw new Error(`Unsupported provider: ${candidate.provider}`);
  }

  return candidate;
}

export function normalizeBaseUrl(baseUrl: string): string {
  return baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
}
